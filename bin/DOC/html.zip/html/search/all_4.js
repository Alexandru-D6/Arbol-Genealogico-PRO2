var searchData=
[
  ['gen_25',['Gen',['../class_especie.html#a5b4a165d647dafc78f3843bd7a75ae01',1,'Especie']]],
  ['generate_5fkmer_26',['generate_kmer',['../class_especie.html#a331079dc40fa6f583705cf04237f65f3',1,'Especie']]],
  ['get_5fdistancia_27',['get_distancia',['../class_tabla__distancias.html#a6e089ffc77df4827151ea961b456aec4',1,'Tabla_distancias']]],
  ['get_5fespecie_28',['get_especie',['../class_cjt__especie.html#ad37396e8db31f698ea2a50f1b0e0324f',1,'Cjt_especie']]],
  ['get_5fgen_29',['get_gen',['../class_especie.html#a750a6f44527090097769dbd4cf905752',1,'Especie']]]
];
