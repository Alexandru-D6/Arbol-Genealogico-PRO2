var searchData=
[
  ['gen_101',['Gen',['../class_especie.html#a5b4a165d647dafc78f3843bd7a75ae01',1,'Especie']]]
];
