var searchData=
[
  ['distancia_5fentre_70',['distancia_entre',['../class_especie.html#aa06ea3b66921825673a30313d84035bc',1,'Especie']]],
  ['distancia_5fminima_71',['distancia_minima',['../class_tabla__distancias.html#a56fb68da543e0dc75bb4b52220796ee3',1,'Tabla_distancias']]]
];
