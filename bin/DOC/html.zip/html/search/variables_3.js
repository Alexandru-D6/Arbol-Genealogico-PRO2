var searchData=
[
  ['k_102',['k',['../class_especie.html#a592c0ddeeebc786969f3040fbefea9df',1,'Especie']]],
  ['kmer_103',['kmer',['../class_especie.html#aa438e3e2f785d96c0ac51e83f60a5879',1,'Especie']]]
];
