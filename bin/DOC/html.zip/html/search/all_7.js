var searchData=
[
  ['leer_5fcjt_5fespecie_35',['leer_cjt_especie',['../class_cjt__especie.html#ac6093b11c9390a7969ba5d6f52062380',1,'Cjt_especie']]],
  ['leer_5fespecie_36',['leer_especie',['../class_especie.html#a63baa790749c0b99a42182f67976936d',1,'Especie']]],
  ['limpiar_5ftabla_37',['limpiar_tabla',['../class_tabla__distancias.html#ac7ff27c32c6c05165b6e49a58f23d1ca',1,'Tabla_distancias']]]
];
