/** @file Especie.hh
 *  @brief Especificacion de la clase Especie.
 */

#ifndef ESPECIE_HH
#define ESPECIE_HH

#ifndef NO_DIAGRAM // sirve para ocultar este include al doxygen
#include <string>  // y de esta manera que no salga en el diagrama
#include <map>     // pero el compilador sigue viendo el include
using namespace std;
#endif

/** @class Especie
    @brief Representa una especie con un gen.
*/

class Especie {
public:
    //Constructoras

    /** @brief Creadora por defecto.

        Se ejecuta automáticamente al declarar una Especie.
        \pre cierto.
        \post El resultado es una especie sin gen.
    */  
    Especie();

    /** @brief Creadora con parametros.

        Permite crear una especie con valores iniciales.
        \pre El gen solamente los caracteres (A, C, T, G).
        \post El resultado es una especie.
    */  
    Especie(const string& gen);

    /** @brief Destructora por defecto.
    */
    ~Especie();

    //Modificadoras

    /** @brief Modificadora del gen.
        
        Modifica el gen del parametro implicito.
        \pre Cierto.
        \post Modifica el gen del parametro implicito.
    */ 
    void mod_gen(const string& gen);

    /** @brief Modificadora valor para generar kmer.
        
        \pre Cierto.
        \post Modifica el parametro implicito.
    */ 
    static void mod_k(const int& i);

    //Consultoras

    /** @brief Consultora del gen.
        
        Retorna el gen del parametro implicito.
        \pre El parametro implicito contiene un gen valido.
        \post El resultado es el gen del parametro implicito.
    */ 
    string get_gen();

    /** @brief Procesardora de distancia.
        
        Calcula la distancia que hay entre dos especies.
        \pre Ambas especies deben ser validos.
        \post Devuelve la distancia entre especies.
    */ 
    static double distancia_entre(const Especie& a, const Especie& b);

    /** @brief Consultora del valor del generador de kmer.
        
        \pre Cierto.
        \post Devuelve el valor k.
    */ 
    static int get_k();


    //Lectura y escritura

    /** @brief Operacion de lectura.
        
        \pre Esta disponible un string correspondientes al gen en el canal
            general de entrada con valor valido.
        \post El gen del parametro implicito es modificado.
    */ 
    void leer_especie();    

    /** @brief Operacion de escritura.
        
        \pre cierto.
        \post El gen del parametro implicito es impreso por el
              canal general de salida.
    */ 
    void escribir_especie();  

private:
    string Gen;

    //set del gen dividido en substring de longitud k, especificado al inicio 
    //del programa.
    map<string, int> kmer;

    static int k;

    //crea la secuencia de string que determina el kmer de la especie
    void generate_kmer();

};
#endif