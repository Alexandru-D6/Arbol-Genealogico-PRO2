/** @file Tabla_distancias.hh
 *  @brief Especificacion de la tabla de distancias.
 */

#ifndef TABLA_DISTANCIAS_HH
#define TABLA_DISTANCIAS_HH

#include "Especie.hh"

#ifndef NO_DIAGRAM   // sirve para ocultar este include al doxygen
#include <map>       // y de esta manera que no salga en el diagrama
using namespace std; // pero el compilador sigue viendo el include
#include <iostream>
#include <set>
#endif

/** @class Tabla_distancias
    @brief Representa una tabla cuadrada de las distancias entre distancias
*/

class Tabla_distancias {
public:

    //Constructoras
    Tabla_distancias();

    Tabla_distancias(const Tabla_distancias& a);

    ~Tabla_distancias();

    //Modificadoras

    /** @brief Modificadora que añade una especie.
        
        \pre cierto.
        \post La especie es añadida a la tabla con la distancia especificada.
    */ 
    void anadir_distancia(const string& id1, const string& id2, const double& dist);

    /** @brief Modificadora de distancia.
        
        \pre cierto.
        \post La distancia que hay entre ambas especies es cambiada.
    */ 
    void modificar_distancia(const string& id1, const string& id2, const double& dist);

    /** @brief Modificadora que elimina una especie.
        
        \pre Ambas especies existen en el parametro implicito, con cualquier distancias.
        \post Las distancias que hacen referencia a la especie son eliminadas, a su
              vez retorna un bool que indica si se ha podido eliminar sadisfactoriamente
              la especie o no, con un true o false respectivamente.
    */ 
    bool eliminar_especie(const string& id);

    /** @brief Vaciadora de tabla.
        
        \pre cierto.
        \post Elimina todas las especies.
    */ 
    void limpiar_tabla();

    //Consultoras

    /** @brief Consultora de distancia.
        
        \pre cierto.
        \post La tabla de distancias del parametro implicito son enviados por el canal
              general de salida.
    */ 
    double get_distancia(const string& id1, const string& id2) const;

    /** @brief Consultora de tamaño.
        
        \pre cierto.
        \post Retorna el tamaño del map;
    */ 
    int size() const;

    /** @brief 
        
        \pre 
        \post 
    */ 
    set<string> get_ids() const;

    /** @brief 
        
        \pre 
        \post 
    */ 
    bool existe_especie(const string& id);

    /** @brief 
        
        \pre 
        \post 
    */ 
    double distancia_minima(string& id1, string& id2);

    //Escritura

    /** @brief Operacion de escritura.
        
        \pre cierto.
        \post La tabla de distancias del parametro implicito son enviados por el canal
              general de salida.
    */ 
    void escribir_tabla();
    
private:

    map<string, map<string,double> > M_dist;
};

#endif