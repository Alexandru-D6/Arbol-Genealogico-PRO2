 #include "Cjt_especie.hh"

Cjt_especie::Cjt_especie() {
    especies.clear();
}
  
Cjt_especie::Cjt_especie(const Cjt_especie& C) {
    especies = C.especies;
}

Cjt_especie::~Cjt_especie() {}

bool Cjt_especie::existe_especie(const string& id) {
    map<string,Especie>::iterator it = especies.find(id);

    return it != especies.end();
}

Especie Cjt_especie::get_especie(const string& id) {
    return especies[id];
}

bool Cjt_especie::anadir_especie(const string& id, const Especie& esp, Tabla_distancias& tabla) {
    map<string,Especie>::iterator it = especies.find(id);

    if (it != especies.end()) return false;
    else {
        especies.insert(make_pair(id,esp));

        calcular_distancias(id, esp, tabla);

        return true;
    }
}

bool Cjt_especie::eliminar_especie(const string& id, Tabla_distancias& tabla) {
    map<string,Especie>::iterator it = especies.find(id);

    if (it == especies.end()) return false;
    else {
        especies.erase(id);

        tabla.eliminar_especie(id);

        return true;
    }
}

void Cjt_especie::leer_cjt_especie(Tabla_distancias& tabla) {
    especies.clear();
    tabla.limpiar_tabla();
    int n_especies; cin >> n_especies;

    for (int i = 0; i < n_especies; ++i) {
        string id; cin >> id;
        Especie esp;
        esp.leer_especie();

        especies.insert(make_pair(id, esp));
    }

    for (map<string,Especie>::iterator it = especies.begin(); it != especies.end(); ++it) {
        calcular_distancias(it->first, it->second, tabla);
    }
}

void Cjt_especie::escribir_cjt_especie() {
    for (map<string,Especie>::iterator it = especies.begin(); it != especies.end(); ++it) {
        cout << it->first << ' ';
        it->second.escribir_especie();
    }
}

void Cjt_especie::calcular_distancias(const string& id, const Especie& a, Tabla_distancias& tabla) {
    for (map<string,Especie>::const_iterator it = especies.begin(); it != especies.end(); ++it) {
        double dist = Especie::distancia_entre(a, it->second);
        tabla.anadir_distancia(id, it->first, dist);
        tabla.anadir_distancia(it->first, id, dist);
    }
}